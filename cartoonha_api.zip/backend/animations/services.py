"""
This file is provided for db related queries for animation app
"""

import django
django.setup()

from animations.models import  Animation, Epizode
from django.shortcuts import get_object_or_404
import json
import datetime

# Custom function to handle non-serializable objects
def default_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()  # Convert datetime to string
    raise TypeError(f"Type {type(obj)} not serializable")



def get_all_animations():
    """ query all the published animations(animations) and sort descending"""

    animations = Animation.objects.filter(
    published=True
    ).order_by(
    '-id'
    )

    animations_data = []
    for animation in animations:
        animations_data.append( {
            'title': animation.title,  
            'replay_count': animation.replay_count,
            'poster_url': animation.poster.url
        })
    
    return json.dumps(animations_data, default=default_serializer, indent=4)



def get_animation(animation_id: int):
    """ query a animation(animation) including its epizodes"""
    animation =  get_object_or_404(
        Animation,
        id=animation_id,
        published=True)
    
    animation_data = {
        'title': animation.title,
        'description': animation.description,
        'poster': animation.poster.url,
        'replay_count': animation.replay_count,
        'published': animation.published,
        'epizodes': []
    }

    for epizode in animation.epizodes.values('id', 'video_embeded_code'):
        animation_data['epizodes'].append(epizode)

    return json.dumps(animation_data, default=default_serializer, indent=4)



def get_epizode(epizode_id):
    """query an apizode by epizode_id """
    epizode = get_object_or_404(Epizode, id=epizode_id)
    epizode_data = {
        'epizode_number': epizode.epizode_number,
        'video_embeded_code': epizode.video_embeded_code,
        'animation_title': epizode.animation.title
    }

    return json.dumps(epizode_data, default=default_serializer, indent=4)



