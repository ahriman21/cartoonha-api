from django.http import JsonResponse
from animations.services import *
from django.conf import settings

# Create your views here.


def get_all_animations_view(request):
    if is_request_unauthorized(request):
        return JsonResponse({"error": "unauthorized 401"})
    if request.method == 'GET':
        return JsonResponse(get_all_animations(), safe=False)
    

def get_animation_view(request, animation_id: int):
    if is_request_unauthorized(request):
        return JsonResponse({"error": "unauthorized 401"})
    if request.method == 'GET':
        return JsonResponse(get_animation(animation_id), safe=False)
    

def get_epizode_view(request, epizode_id: int):
    if is_request_unauthorized(request):
        return JsonResponse({"error": "unauthorized 401"})
    if request.method == 'GET':
        return JsonResponse(get_epizode(epizode_id), safe=False)
    

# helper
def is_request_unauthorized(request):
    api_key = request.headers.get('Authorization')
    if api_key != f"Bearer {settings.API_KEY}":
        return True
    else:
        return False
