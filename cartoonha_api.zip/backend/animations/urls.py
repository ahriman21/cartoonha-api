from django.urls import path
from animations.views import(get_all_animations_view,
                       get_animation_view,
                       get_epizode_view)

urlpatterns = [
    path('animations/', get_all_animations_view),
    path('animation/<animation_id>/', get_animation_view),
    path('epizode/<epizode_id>/', get_epizode_view,)
]