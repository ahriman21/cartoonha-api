from django.contrib import admin
from .models import Animation, Epizode


# Register your models here.
admin.site.register(Animation)
admin.site.register(Epizode)