from django.db import models



class Animation(models.Model):
    title = models.CharField(max_length=50)
    description = models.TextField(max_length=500)
    poster = models.ImageField()
    replay_count = models.IntegerField(default=0)
    published = models.BooleanField(default=False)

    def __str__(self):
        return self.title




class Epizode(models.Model):
    epizode_number = models.SmallIntegerField()

    video_embeded_code = models.CharField(
        help_text="video's embeded code from aparat or other services",
        max_length=500
    )
    
    animation = models.ForeignKey(
        Animation,
            on_delete=models.CASCADE,
            related_name='epizodes'
        )


    def __str__(self):
        animation_title = self.animation.title if self.animation else ""
        return animation_title + " " + str(self.epizode_number)



